//
//  YLReportCenter.swift
//  YLVideo
//
//  Created by zhoubl on 2018/12/13.
//  Copyright © 2018 zhoubl. All rights reserved.
//

import UIKit
import AdSupport
import Alamofire
import SystemConfiguration.CaptiveNetwork
let reportBaseUrl = "http://data.1lan.tv"

class YLReportCenter
{
    static let shared = YLReportCenter()
    
    private var loadid = UUID().uuidString  // 每次启动唯一
    // 内部测试机器不进行上报加密
    private var uuidList = ["8E373666-6449-44C0-8BF7-3E0021EE4ABD",
                            "7162FBBB-7B73-46AE-96CE-7FA6DAE61B7B",
                            "F94C480C-ED00-437A-91AF-E318A1937AC5",
                            "A2C4DC8E-BD5F-4D55-8E9B-B14981DD5FEC",
                            "C8828B99-4366-40A0-8872-64AD3ECB8B6A",
                            "16AAC9CF-6CFA-4CED-B5C4-121EE34AE04D",
                            "A0046DF0-CD2E-447A-A5B8-16AE9FB2901E",
                            "C886E774-BBC5-4C0E-93DB-92E649466330",
                            "B2383B7A-D80C-423F-B8CB-DBEDD4839718",
                            "A7D7EB08-73B4-4E6D-959C-1D637645468A",
                            "713106A8-3D89-4C7F-9650-04B586FD7F3B",
                            "1D91127F-63CB-4065-A05C-DB4B64C3C53E",
                            "23B69587-4273-45A5-A126-8760E1487447",
                            "B7B29F8A-9578-4B63-B981-A916DABEBB85",
                            "B9E800BC-123D-4841-A49F-902C5787009A"]

    private var defaultParameters : [String : String]
    {
        get
        {
            let sn = "\(Int64(Date().timeIntervalSince1970 * 1000))"
            let version = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
            let build = Bundle.main.infoDictionary!["CFBundleVersion"] as! String
            let ver = "\(version).\(build)"
            let parameters = ["access_key" : accessKey,
                              "udid" : YLUUID.value,
                              "uid":"0",
//                              "mac":self.getMAC(),
                              "idfa" : ASIdentifierManager.shared().advertisingIdentifier.uuidString,
                              "brand" : "apple",
                              "model" : UIDevice.current.machine,
                              "ver" : ver,
                              "nt" :YLReportCenter.getNetworkString(),
                              "telecom" : YLWWAN.mobileNetworkType.rawValue,
                              "sn" : sn]
            return parameters
        }
    }
    
    func send(path: String, parameters: [String: String]?)
    {
        // url + path + 部分参数
        let params = getParamteters()
        var totalUrl = reportBaseUrl
        var i = 0
        for key in params.keys {
            if i == 0 {
                totalUrl += "?"
            } else {
                totalUrl += "&"
            }
            i += 1
            if let value = params[key] {
                totalUrl += key + "=" + value
            }
        }

        // post data
        var postContent: [String : Any] = self.defaultParameters
        postContent += ["event" : path]
        if parameters != nil {
            postContent += ["body" : parameters!]
        }
        let content = getJSONString(from: postContent)
        if let data = content {
            upload(data, to: totalUrl, headers: ["Content-Type" : "application/json; charset=utf-8"]).responseString { (response) in
                print(response.result.value as Any)
            }
//            if uuidList.contains(YLUUID.value) {
//                upload(data, to: totalUrl, headers: ["Content-Type" : "application/json; charset=utf-8"]).responseString { (response) in
//                    print(response.result.value as Any)
//                }
//            } else {
//                let xorData = obfuscate(bytes: data)
//                upload(xorData.base64EncodedData(), to: totalUrl, headers: ["Content-Type" : "application/json; charset=utf-8"])
//            }
        }
        
    }
    
    
    static private var taskID: [String: String] = [:]
    class func resetTaskID(with videoID: String)
    {
        taskID[videoID] = "\(Int64(Date().timeIntervalSince1970 * 1000))"
    }
    
    class func taskID(from videoID: String) -> String
    {
        if let ID = taskID[videoID] {
            return ID
        } else {
            return ""
        }
    }
    
    private func getParamteters() -> [String: String]
    {
        let timeStamp = Int64(Date().timeIntervalSince1970 * 1000)
        let udid = YLUUID.value
        
        let sign_head = "13149876"
        let sign_tail = "98761314"
        
        let md5String = sign_head + "\(timeStamp)" + accessKey + udid + sign_tail
        let md5 = YLTools.MD5(from: md5String) ?? ""
        
        
        return ["ts": "\(timeStamp)", "access_key": accessKey, "udid": udid, "m": md5]
    }

    func getJSONString(from dictionary: Dictionary<String, Any>) -> Data? {
        if (!JSONSerialization.isValidJSONObject(dictionary)) {
            return nil
        }
        if #available(iOS 11.0, *) {
            let data = try? JSONSerialization.data(withJSONObject: dictionary, options: [.sortedKeys])
            return data
        } else {
            let data = try? JSONSerialization.data(withJSONObject: dictionary, options: [])
            return data
        }
        
    }
    
    func obfuscate(bytes: Data) -> Data
    {
        var myByte = [UInt8](bytes)
        for i in 0..<bytes.count {
            myByte[i] = myByte[i] ^ 0x10
        }
        return Data(bytes: myByte, count: myByte.count)
    }
    
    static func getNetworkString() -> String
    {
        let status = YLNetworkManager.shared.status
        if status == .wifi {
            return "1"
        } else if status == .wwan {
            let wwanType = YLWWAN.telephonyType
            if wwanType == .type3G {
                return "3"
            } else if wwanType == .type4G {
                return "4"
            } else {
                return "2"
            }
        }
        return ""
    }
    
    func getMAC()->String{

            let interfaces:NSArray = CNCopySupportedInterfaces()!

//            var ssid: String?

            var mac: String?

            for sub in interfaces

            {

                if let dict = CFBridgingRetain(CNCopyCurrentNetworkInfo(sub as! CFString))

                {

//                    ssid = dict["SSID"] as? String

                    mac = dict["BSSID"] as? String

                }

            }
        return mac ?? ""

        }
}



