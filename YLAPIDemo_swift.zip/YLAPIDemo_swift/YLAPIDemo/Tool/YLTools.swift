//
//  YLTools.swift
//  YLVideo
//
//  Created by zhoubl on 2018/12/13.
//  Copyright © 2018 zhoubl. All rights reserved.
//

import UIKit
import CommonCrypto
import MobileCoreServices
import WebKit
import CryptoSwift
class YLTools
{
    class func ylPresent(currentVc:UIViewController,targtVc:UIViewController,completion: @escaping (Bool) -> Void){
        currentVc.addChild(targtVc)
        currentVc.view.addSubview(targtVc.view)
        targtVc.view.frame  = CGRect.init(x: 0, y: currentVc.view.frame.size.height, width: currentVc.view.frame.size.width, height: currentVc.view.frame.height)
        if currentVc == (UIApplication.shared.keyWindow?.rootViewController)! {
            targtVc.viewDidAppear(false)
        }
        UIView.animate(withDuration: 0.2) {
            targtVc.view.frame = currentVc.view.bounds
        } completion: { (result) in
            currentVc.viewWillDisappear(true)
//            currentVc.viewDidAppear(true)
            completion(result)
        }
    }
    
    class func ylDismiss(currentVc:UIViewController){
            UIView.animate(withDuration: 0.2) {
                currentVc.view.frame = CGRect.init(x: 0, y: currentVc.view.frame.size.height, width: currentVc.view.frame.size.width, height: currentVc.view.frame.size.height)
            } completion: { (result) in
                currentVc.parent?.viewDidAppear(true)
                currentVc.view.removeFromSuperview()
                currentVc.removeFromParent()
            }
    }
    
    
    class func dnsToIP(urlHost: String?) -> String?
    {
        guard let urlHost = urlHost else {
            return nil
        }
        let host = CFHostCreateWithName(nil, urlHost as CFString).takeRetainedValue()
        CFHostStartInfoResolution(host, .addresses, nil)
        var success: DarwinBoolean = false
        if let addresses = CFHostGetAddressing(host, &success)?.takeUnretainedValue() as NSArray? {
            for case let theAddress as NSData in addresses {
                var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                if getnameinfo(theAddress.bytes.assumingMemoryBound(to: sockaddr.self), socklen_t(theAddress.length),
                               &hostname, socklen_t(hostname.count), nil, 0, NI_NUMERICHOST) == 0 {
                    let numAddress = String(cString: hostname)
                    return numAddress
                }
            }
        }
        return nil
    }
    // MARK: - 添加加盐MD5
    class func getAddSaltMD5(_ dic:[String:String], salt: String) ->([String:String])
    {
        var param = dic
        param["timestamp"] = YLTools.timeStampMsec
        let keyArray = Array(param.keys).sorted { $0 < $1 }
        var jointStr = ""
        for key in keyArray {
            let value:String  = param[key]!
            jointStr = String.init(format: "%@%@=%@&", jointStr,key,value)
        }
        jointStr  = jointStr + "salt=" + salt
        
        param["sign"] = self.MD5(from: jointStr)
        return param
    }
    
    class func MD5(from: String) -> String?
    {
        guard let str = from.cString(using: String.Encoding.utf8) else {
            return nil
        }
        let strLen = CUnsignedInt(from.lengthOfBytes(using: String.Encoding.utf8))
        let digestLen = Int(CC_MD5_DIGEST_LENGTH)
        let result = UnsafeMutablePointer<CUnsignedChar>.allocate(capacity: digestLen)
        CC_MD5(str, strLen, result)
        let hash = NSMutableString()
        for i in 0 ..< digestLen {
            hash.appendFormat("%02x", result[i])
        }
        result.deallocate()
        return String(format: hash as String)
    }
    
    private static var _isIphoneX: Bool?
    class var isIphoneX : Bool {
        get {
            if _isIphoneX == nil {
                _isIphoneX = UIScreen.main.bounds.height > 811
                //                gStatusBarHeight = 44
            }
            return _isIphoneX!
        }
    }
    
    class var timeStampMsec: String {
        return String(format: "%.0f", NSDate().timeIntervalSince1970 * 1000)
    }
    
    class var timeStampSec: String {
        return String(format: "%.0f", NSDate().timeIntervalSince1970)
    }
    
    // 从秒转换为00:00:00格式文本
    class func getFormateTime(_ time: TimeInterval) -> String
    {
        var nTime: Int = 0
        if !time.isNaN {
            nTime = Int(time)
        }
        let hours = nTime / 3600;
        let minites = (nTime - 3600 * hours) / 60;
        let seconds = nTime % 60;
        
        var str = "";
        if hours > 0 {
            str = String(format: "%02d:%02d:%02d", hours, minites, seconds)
        } else {
            str = String(format: "%02d:%02d", minites, seconds)
        }
        return str
    }
    
    class func formatNumber(_ number: Int) -> String
    {
        var numStr: String
        if number > 10000 * 10000 {
            let yi = Float(number) / (10000 * 10000)
            numStr = String.init(format: "%.1f亿", yi)
        } else if number > 10000 {
            let wan = Float(number) / 10000
            numStr = String.init(format: "%.1f万", wan)
        } else {
            numStr = "\(number)"
        }
        return numStr
    }
    
    class func isEmptyString(string: String?) -> Bool {
        if string == nil || string!.count == 0 || string!.replacingOccurrences(of: " ", with: "", options: .literal, range: nil).count == 0 {
            return true
        } else {
            return false
        }
    }
    
    class func getJsonString(dic: Dictionary<String, Any>) -> String
    {
        var jsonString = ""
        if let data = try? JSONSerialization.data(withJSONObject: dic, options: .prettyPrinted) {
            jsonString = String(data: data, encoding: .utf8) ?? ""
            jsonString = jsonString.replacingOccurrences(of: " ", with: "")
            jsonString = jsonString.replacingOccurrences(of: "\r", with: "")
            jsonString = jsonString.replacingOccurrences(of: "\n", with: "")
            jsonString = jsonString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        }
        return jsonString
    }
    
    private static var userAgentString: String?
    static var uaWebView: WKWebView?
    @discardableResult class func getUserAgent() -> String
    {
        if userAgentString == nil {
            uaWebView = nil
            DispatchQueue.main.async {
                uaWebView = WKWebView()
                uaWebView?.evaluateJavaScript("navigator.userAgent") { (result, error) in
                    if let oldAgent = result as? String {
                        let version = Bundle.main.infoDictionary!["CFBundleShortVersionString"] as! String
                        let systemVersion = UIDevice.current.systemVersion
                        let iphoneScale = UIScreen.main.scale
                        let model = UIDevice.current.model
                        let localeIdentifier = NSLocale.current.identifier
                        let identifier = Bundle.main.bundleIdentifier ?? ""
                        let appendAgent = "\(identifier)/\(version) (\(model)/\(systemVersion); \(localeIdentifier); Scale\(iphoneScale))"
                        let newAgent = "\(oldAgent) \(appendAgent)"
                        userAgentString = newAgent
                        uaWebView = nil
                    }
                }
            }
        }
        return userAgentString ?? ""
    }
    
    /// 是越狱设备
    private static var _isJailBreak: Bool?
    class func isJailBreak() -> Bool
    {
        if _isJailBreak == nil {
            _isJailBreak = false
            let jailbreakToolPathes = ["/Applications/Cydia.app",
                                       "/Library/MobileSubstrate/MobileSubstrate.dylib",
                                       "/bin/bash",
                                       "/usr/sbin/sshd",
                                       "/etc/apt"]
            
            for path in jailbreakToolPathes {
                if FileManager.default.fileExists(atPath: path) {
                    _isJailBreak = true
                }
            }
        }
        
        return _isJailBreak!
    }
    

    
}



struct YLAES {

    public static func Endcode_AES_ECB(strToEncode:String)->String {
        // 从String 转成data
        let data = strToEncode.data(using: String.Encoding.utf8)

        // byte 数组
        var encrypted: [UInt8] = []
        do {
            encrypted = try AES(key: accessToken, iv: String(accessToken.prefix(16))).encrypt(data!.bytes)
        } catch {
        }

        let encoded =  Data(encrypted)
        //加密结果要用Base64转码
        return encoded.base64EncodedString()
    }

    public static func Decode_AES_ECB(strToDecode:String)->String {
        //decode base64
        let data = Data(base64Encoded: strToDecode, options: Data.Base64DecodingOptions(rawValue: 0))

        // decode AES
        var decrypted: [UInt8] = []
        do {
            decrypted = try AES(key: accessToken, iv: String(accessToken.prefix(16))).decrypt(data!.bytes)
        } catch {
        }
        
        var str = ""
        //解密结果从data转成string
        str = String(bytes: decrypted, encoding: .utf8) ?? ""
        
        return str
    }

}
