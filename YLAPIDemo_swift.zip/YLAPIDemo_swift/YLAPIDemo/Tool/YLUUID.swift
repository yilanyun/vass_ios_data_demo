//
//  UDID.swift
//  YLVideo
//
//  Created by zhoubl on 2018/12/13.
//  Copyright © 2018 zhoubl. All rights reserved.
//

import UIKit
import Security
import UIKit

class YLUUID
{
    //  同一个开发证书下相同key会被认为是同一个app
    private static let kValueKey = "YLOpenSDK"
    
    private static var _value : String = ""
    static var value : String {
        get {
            if _value.count == 0 {
                if let valueInUD = UserDefaults.standard.value(forKey: kValueKey) as? String {
                    _value = valueInUD
                } else {
                    let pb = UIPasteboard.init(name: UIPasteboard.Name.init(kValueKey), create: true)
                    if let valueInPB = pb?.string {
                        _value = valueInPB
                    } else {
                        _value = UUID().uuidString
                    }
                }
                self.saveValue(_value)
            }
            return _value
        }
    }
    
    private static func saveValue(_ newValue: String)
    {
        UserDefaults.standard.set(newValue, forKey: kValueKey)
        let pb = UIPasteboard.init(name: UIPasteboard.Name.init(kValueKey), create: true)
        pb?.string = newValue
    }
    
    static func reset()
    {
        _value = UUID().uuidString
        self.saveValue(_value)
    }
    
}
