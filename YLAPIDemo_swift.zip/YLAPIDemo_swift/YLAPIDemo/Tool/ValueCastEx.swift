//
//  ValueCastEx.swift
//  YLHowTo
//
//  Created by zhoubl on 2018/1/22.
//  Copyright © 2018年 yilan. All rights reserved.
//

import UIKit
import UIKit

extension UInt32
{
    var intValue: Int {
        get {
            return Int(self)
        }
    }
    
    var floatValue: Float {
        get {
            return Float(self)
        }
    }
    
    var doubleValue: Double {
        get {
            return Double(self)
        }
    }
    
    var cgFloatValue: CGFloat {
        get {
            return CGFloat(self)
        }
    }
    
    var stringValue: String {
        get {
            return String("\(self)")
        }
    }
    
    var boolValue: Bool {
        get {
            return self != 0
        }
    }
    
    var isZero: Bool {
        return self == 0
    }
}

extension Int
{
    var uInt32Value: UInt32 {
        get {
            return UInt32(self)
        }
    }
    
    var floatValue: Float {
        get {
            return Float(self)
        }
    }
    
    var doubleValue: Double {
        get {
            return Double(self)
        }
    }
    
    var cgFloatValue: CGFloat {
        get {
            return CGFloat(self)
        }
    }
    
    var stringValue: String {
        get {
            return String("\(self)")
        }
    }
    
    var boolValue: Bool {
        get {
            return self != 0
        }
    }
    
    var isZero: Bool {
        return self == 0
    }
    
    var max99: String {
        return self > 99 ? "99+" : "\(self)"
    }
    
    var overTenThousand: Bool {
        return self >= 10000
    }
    
}

extension Double
{
    var uInt32Value: UInt32 {
        get {
            return UInt32(self)
        }
    }
    
    var floatValue: Float {
        get {
            return Float(self)
        }
    }
    
    var intValue: Int {
        get {
            return Int(self)
        }
    }
    
    var int64Value: Int64 {
        get {
            return Int64(self)
        }
    }
    
    var cgFloatValue: CGFloat {
        get {
            return CGFloat(self)
        }
    }
    
    var stringValue: String {
        get {
            return String("\(self)")
        }
    }
    
    var decimalString: String {
        var string = NSDecimalNumber(value: self).stringValue
        let stringArray = string.components(separatedBy: ".")
        if stringArray.count == 2 {
            if stringArray[1].count > 2 {
                string = String(format: "%.2f", self)
            }
        }
        return string
    }
    
    var boolValue: Bool {
        get {
            return self != 0
        }
    }
    
    var isZero: Bool {
        return self == 0
    }
}

extension Float
{
    var uInt32Value: UInt32 {
        get {
            return UInt32(self)
        }
    }
    
    var intValue: Int {
        get {
            return Int(self)
        }
    }
    
    var doubleValue: Double {
        get {
            return Double(self)
        }
    }
    
    var cgFloatValue: CGFloat {
        get {
            return CGFloat(self)
        }
    }
    
    var stringValue: String {
        get {
            return String("\(self)")
        }
    }
    
    var boolValue: Bool {
        get {
            return self != 0
        }
    }
    
    var isZero: Bool {
        return self == 0
    }
}

extension CGFloat
{
    var uInt32Value: UInt32 {
        get {
            return UInt32(self)
        }
    }
    
    var intValue: Int {
        get {
            return Int(self)
        }
    }
    
    var doubleValue: Double {
        get {
            return Double(self)
        }
    }
    
    var floatValue: Float {
        get {
            return Float(self)
        }
    }
    
    var stringValue: String {
        get {
            return String("\(self)")
        }
    }
    
    var boolValue: Bool {
        get {
            return self != 0
        }
    }
    
    var isZero: Bool {
        return self == 0
    }
}

extension String
{
    var intValue: Int {
        get {
            return Int(self) ?? 0
        }
    }
    
    var doubleValue: Double {
        get {
            return Double(self) ?? 0
        }
    }
    
    var floatValue: Float {
        get {
            return Float(self) ?? 0
        }
    }
    
    var cgFloatValue: CGFloat {
        get {
            return CGFloat((self as NSString).doubleValue)
        }
    }
    
    var boolValue: Bool {
        get {
            return self != "0"
        }
    }
}

extension Bool
{
    var intValue: Int {
        return self ? 1 : 0
    }
}
