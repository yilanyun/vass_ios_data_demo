//
//  YLAPICommon.swift
//  YLAPIDemo
//
//  Created by Jabne on 2021/7/6.
//

import UIKit

let accessKey:String = "ylel2vek386q"
let accessToken:String = "e2gn3wn9ymyhg4ra16zzfuxeiyegwaod"
