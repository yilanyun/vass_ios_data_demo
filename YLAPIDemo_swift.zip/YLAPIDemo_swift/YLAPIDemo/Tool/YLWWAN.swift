//
//  YLWWAN.swift
//  YLVideo
//
//  Created by zhoubl on 2018/12/13.
//  Copyright © 2018 zhoubl. All rights reserved.
//

import Foundation
import CoreTelephony
import SystemConfiguration.CaptiveNetwork

class YLWWAN
{
    enum TelephonyType {
        case unkown
        case type2G
        case type3G
        case type4G
    }
    
    // 取值于数据上报的要求对应
    enum MobileNetworkType: String {
        case telecom = "1" // 电信
        case mobile = "2" // 移动
        case unicom = "3" // 联通
        case other = "4"
    }
    
    static var telephonyType: TelephonyType {
        var _type: TelephonyType = .unkown
        if let technology = telephonyNetworkInfo.currentRadioAccessTechnology
        {
            if telephony2Gs.contains(technology) {
                _type = .type2G
            } else if telephony3Gs.contains(technology) {
                _type = .type3G
            } else if telephony4Gs.contains(technology) {
                _type = .type4G
            }
        }
        return _type
    }
    
    static var mobileNetworkType: MobileNetworkType {
        let carrier = telephonyNetworkInfo.subscriberCellularProvider
        
        var mobile: MobileNetworkType = .other
        if carrier?.isoCountryCode != nil
        {
            if let carriercode = carrier?.mobileNetworkCode {
                if carriercode == "00" || carriercode == "02" || carriercode == "07" {
                    mobile = .mobile    // 移动
                } else if carriercode == "03" || carriercode == "05" {
                    mobile = .telecom    // 电信
                } else if carriercode == "01" || carriercode == "06" {
                    mobile = .unicom    // 联通
                }
            }
        }
        return mobile
    }
    
    static var imsi: String {
        let carrier = telephonyNetworkInfo.subscriberCellularProvider
        let countryCode = carrier?.mobileCountryCode ?? ""
        let networkCode = carrier?.mobileNetworkCode ?? ""
        return countryCode + networkCode
    }
    
    static var mcc: String {
        let carrier = telephonyNetworkInfo.subscriberCellularProvider
        return carrier?.mobileCountryCode ?? ""
    }
    
    static var wifiInfo: (String, String) {
        var wifiName: String = ""
        var wifiAddress: String = ""
        let wifiInterfaces = CNCopySupportedInterfaces()
        if let interfaces = wifiInterfaces, let interfaceArr = CFBridgingRetain(interfaces) as? Array<String> {
            if interfaceArr.count > 0 {
                let interfaceName = interfaceArr[0] as CFString
                let ussafeInterfaceData = CNCopyCurrentNetworkInfo(interfaceName)
                if (ussafeInterfaceData != nil) {
                    if let interfaceData = ussafeInterfaceData as? Dictionary<String, Any> {
                        if let name = interfaceData["SSID"] as? String {
                            wifiName = name
                        }
                        if let address = interfaceData["BSSID"] as? String {
                            wifiAddress = address
                        }
                    }
                }
            }
        }
        return (wifiName, wifiAddress)
    }
    
    private static let telephony2Gs = [CTRadioAccessTechnologyEdge,CTRadioAccessTechnologyGPRS]
    private static let telephony3Gs = [CTRadioAccessTechnologyHSDPA,
                                       CTRadioAccessTechnologyWCDMA,
                                       CTRadioAccessTechnologyHSUPA,
                                       CTRadioAccessTechnologyCDMA1x,
                                       CTRadioAccessTechnologyCDMAEVDORev0,
                                       CTRadioAccessTechnologyCDMAEVDORevA,
                                       CTRadioAccessTechnologyCDMAEVDORevB,
                                       CTRadioAccessTechnologyeHRPD]
    private static let telephony4Gs = [CTRadioAccessTechnologyLTE]
    
    static let telephonyNetworkInfo = CTTelephonyNetworkInfo.init()
    
    static var ipv6Address: String {
        var addresses = [String: String]()
        var interfaces : UnsafeMutablePointer<ifaddrs>? = nil
        if getifaddrs(&interfaces) == 0 {
            var ptr = interfaces
            while (ptr != nil) {
                let flags = Int32(ptr!.pointee.ifa_flags)
                var addr = ptr!.pointee.ifa_addr.pointee
                if (flags & (IFF_UP|IFF_RUNNING|IFF_LOOPBACK)) == (IFF_UP|IFF_RUNNING) {
                    
                    if addr.sa_family == UInt8(AF_INET) || addr.sa_family == UInt8(AF_INET6) {
                        let name = String(validatingUTF8: ptr!.pointee.ifa_name) ?? ""
                        let type = addr.sa_family == AF_INET ? "ipv4" : "ipv6";
                        var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                        if (getnameinfo(&addr, socklen_t(addr.sa_len), &hostname, socklen_t(hostname.count),nil, socklen_t(0), NI_NUMERICHOST) == 0) {
                            if let address = String(validatingUTF8:hostname) {
                                addresses["\(name)/\(type)"] = address
                            }
                        }
                    }
                }
                ptr = ptr!.pointee.ifa_next
            }
            freeifaddrs(interfaces)
        }
        switch YLReportCenter.getNetworkString() {
        case "1":
            for (key, value) in addresses {
                if key.contains("en0"), key.contains("ipv6")  {
                    return value
                }
            }
        case "2", "3", "4":
            for (key, value) in addresses {
                if key.contains("en2"), key.contains("ipv6")  {
                    return value
                }
            }
        default:
            return ""
        }
        return ""
    }
}
