import UIKit
/// Feed流刷新类型
@objc enum YLFeedLoadType: Int {
    /// 上拉加载更多
    case pullUp = 0
    /// 下拉刷新
    case pullDown = 1
    /// 第一次刷新
    case first = 2
}

@objc class YLData: NSObject
{

    /// 单例
    @objc static var shared = YLData()
    
    private let YLUserInfoKey = "YLUserInfoKey"
    
    /**
     频道信息流
     @param videoType : 视频类型，1-横屏，2-竖屏
     @param channel_id : 频道ID
     @param load_type : 0-上拉，1-下拉，2-首次刷新
     @param size : 页大小，范围 1～8
     */
    @objc func getFeedList(videoType: Int,channelId: Int, loadType: YLFeedLoadType,size :Int, callback: @escaping (Bool, [YLFeedModel]?) -> Void)
    {
        let params = ["video_type":videoType,"channel_id" : channelId, "load_type" : "\(loadType.rawValue)","size": size] as [String:Any]
        YLHttpCenter.shared.requestUrl(kGetFeedPath, parameters: params) {
            (result: YLHttpResult, response: YLDataModel<[YLFeedModel]>?) in
            callback(result.success, response?.data ?? [])
        }
    }
    
    /**
     相关视频
     @param videoId : 视频id
     @param size : 页大小，范围 1～20
     */
    @objc func getRelationList(videoId: String,size: String, callback: @escaping (Bool, [YLFeedModel]?) -> Void)
    {
        let params = ["id" : videoId,"size":size]
        YLHttpCenter.shared.requestUrl(kRelationPath, parameters: params) { (result: YLHttpResult, response: YLDataModel<[YLFeedModel]>?) in
            callback(result.success, response?.data ?? [])
        }
    }

    /**
     频道列表
     */
    @objc func getChannels(callback: @escaping (Bool, [YLChannelModel]?) -> Void)
    {
        YLHttpCenter.shared.requestUrl(kGetChannelPath, parameters: [:]) { (result: YLHttpResult, response: YLDataModel<[YLChannelModel]>?) in
            callback(result.success, response?.data ?? [])
        }
    }
    
    /**
     视频详情
     @param videoIds : 视频id用逗号隔开组成的字符串
     @param video_type : 视频类型，1-横屏，2-竖屏
     */
    @objc func getVideoDetail(videoIds: String,videoType:Int, callback: @escaping (Bool, [YLFeedModel]?) -> Void)
    {
        let params = ["ids" : videoIds,"video_type":videoType] as [String : Any]
        YLHttpCenter.shared.requestUrl(kDetailPath, parameters: params) { (result: YLHttpResult, response: YLDataModel<[YLFeedModel]>?) in
            callback(result.success, response?.data)
        }
    }
    
    /**
     获取作者信息
     @param videoId : 视频id
     @param video_type : 视频类型，1-横屏，2-竖屏
     */
    @objc func getCpInfo(cpId: String,videoType: Int,callback: @escaping (Bool, YLProviderModel?) -> Void)
    {
        let params = ["id" : cpId,"video_type":videoType] as [String : Any]
        YLHttpCenter.shared.requestUrl(KCPInfoPath, parameters: params) { (result:YLHttpResult, response:YLDataModel<YLProviderModel>?) in
            callback(result.success,response?.data)
        }
        
    }
    
    /**
     获取作者信息
     @param videoId : 视频id
     @param video_type : 视频类型，1-横屏，2-竖屏
     */
    @objc func getCpVideos(videoId: String,videoType: Int,page: Int,size: Int,callback: @escaping (Bool, [YLFeedModel]?) -> Void)
    {
        let params = ["id" : videoId,"video_type":videoType,"page":page,"size":size] as [String : Any]
        YLHttpCenter.shared.requestUrl(KCPVideosPath, parameters: params) { (result:YLHttpResult, response:YLDataModel<[YLFeedModel]>?) in
            callback(result.success,response?.data)
        }
        
    }
    
     func requestVideoInfo(mediaID : String, callback : @escaping (Bool, [YLBitrateModel]?) -> Void)
    {
        let params = ["id" : mediaID]
        YLHttpCenter.shared.requestUrl(kPlayPath, parameters: params) { (result : YLHttpResult, response : YLDataModel<[YLBitrateModel]>?) in
            callback(result.success, response?.data)
        }
    }
    
}
