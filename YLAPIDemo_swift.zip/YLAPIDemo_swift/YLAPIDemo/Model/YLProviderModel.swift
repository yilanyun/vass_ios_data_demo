//
//  YLProviderModel.swift
//  YLAPIDemo
//
//  Created by Jabne on 2021/7/12.
//

import Foundation
/// CP
@objc public class YLProviderModel: NSObject, Decodable
{
    /// 视频提供者ID
    @objc public var id: String?
    /// 名字
    @objc public var name: String?
    /// 头像
    @objc public var avatar: String?
//    /// 简介
//    @objc public var aword: String?
//    /// 视频数
//    @objc public var videos: String?
    
//    @objc public var cp_choice: String
}
