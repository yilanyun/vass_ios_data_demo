//
//  YLChannelModel.swift
//  YLVideo
//
//  Created by zhoubl on 2018/12/13.
//  Copyright © 2018 zhoubl. All rights reserved.
//

import Foundation

/// 频道-数据结构
 class YLChannelModel: NSObject, Decodable
{
     var id: String?
     var name: String?
}

