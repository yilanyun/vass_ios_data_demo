//
//  brig.m
//  YLAPIDemo
//
//  Created by Jabne on 2021/7/9.
//

#import "brig.h"

@implementation brig

@end
