//
//  YLAPIHomeTableViewController.m
//  YLAPIDemo-OC
//
//  Created by Jabne on 2022/5/23.
//

#import "YLAPIHomeTableViewController.h"
#import "YLData.h"
@interface YLAPIHomeTableViewController ()

@end

@implementation YLAPIHomeTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    switch (indexPath.row) {
        case 0:
            
            [[YLData shared] getFeedListWith:2 channelId:2013 loadType:0 size:10 success:^(id obj) {

                        } failure:^(NSError * _Nonnull error) {

                        }];
            break;
        case 1:
            [[YLData shared] getRelationListWithVideoId:@"vM4P2Rv2xVMY" size:10 success:^(id obj) {
                            
                        } failure:^(NSError * _Nonnull error) {
                            
                        }];
            break;
        case 2:
            [[YLData shared] getChannelsWithsuccess:^(id obj) {
                            
                        } failure:^(NSError * _Nonnull error) {
                            
                        }];
            break;
        case 3:
            [[YLData shared] getVideoDetailWithvideoIds:@"vM4P2Rv2xVMY" videoType:1 success:^(id obj) {
                            
                        } failure:^(NSError * error) {
                            
                        }];
            break;
        case 4:
            [[YLData shared] getCpInfoWithcpId:@"qJy8nVw1ojRY" videoType:1 success:^(id obj) {
                
            } failure:^(NSError * error) {
                
            }];
            break;
        case 5:
            [[YLData shared] getCpVideosWithvideoId:@"qJy8nVw1ojRY" videoType:1 page:1 size:10 success:^(id obj) {
                            
                        } failure:^(NSError * error) {
                            
                        }];
            break;
        case 6:
            [[YLData shared] requestVideoInfoWithVideoId:@"vM4P2Rv2xVMY" success:^(id _Nonnull) {
                            
                        } failure:^(NSError * _Nonnull error) {
                            
                        }];
            break;
        default:
            break;
    }
}

@end
