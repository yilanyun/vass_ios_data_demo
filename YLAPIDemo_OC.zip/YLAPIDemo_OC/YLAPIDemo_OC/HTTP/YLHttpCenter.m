//
//  YLHttpCenter.m
//  YLAPIDemo-OC
//
//  Created by Jabne on 2022/5/23.
//

#import "YLHttpCenter.h"
#import "NSString+Hash.h"
#import "NSString+AES.h"
#import "AFNetworking.h"
#import <CommonCrypto/CommonHMAC.h>
#import "YLAPIDemo_OC-Swift.h"

static NSString *const accessKey = @"ylel2vek386q";
static NSString *const accessToken = @"e2gn3wn9ymyhg4ra16zzfuxeiyegwaod";


//static NSString *const accessKey = @"yluxzovoz0uw";
//static NSString *const accessToken = @"wfyxugqmlriks2juz5qkvt64lxxwrz1c";



static NSString *const baseurl = @"https://api.yilanvaas.cn";
static NSString *const playbaseUrl = @"https://play.yilanvaas.cn";


@implementation YLHttpCenter
{
    AFHTTPSessionManager* manager;
}

+ (instancetype)shared{
    static YLHttpCenter *http = nil ;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (http == nil) {
            http = [[YLHttpCenter alloc]init];
        }
    });
  return http;

}

- (void)requestUrlWithPath:(NSString *)path parameters:(id)parameters success:(void (^)(id _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure{
    
    NSString* host = baseurl;
    if ([path isEqualToString:@"/vaas/video/play"]) {
        host = playbaseUrl;
    }
    
    // 最后请求地址
    NSString* finalUrl = [NSString stringWithFormat:@"%@%@",host,path];
    
    // 公共参数  platform:1-Android，2-iOS，3-H5，4-小程序，5-web
    NSMutableDictionary* publicPar = @{@"platform":@(2),@"udid":@"FA82059E-8235-41A3-9407-071FACDA6993",@"pkg_name":[NSString stringWithFormat:@"%@",[[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleIdentifier"]]}.mutableCopy;
    
    // 将传入的参数加上
    [publicPar addEntriesFromDictionary:parameters];
    
    // 参数字典转json
    NSString* paramsjson = [self convertToJsonData:publicPar];
//    NSString* paramsjson = @"{\"platform\":2,\"pkg_name\":\"tv.yilan.qianpai.app\",\"udid\":\"FA82059E-8235-41A3-9407-071FACDA6993\"}";
    NSLog(@"%@",paramsjson);
    
    // jsonAES加密
    NSString* aesjson = [paramsjson aci_encryptWithAES];
    
    // 当前时间戳
    long nowtime = (long)[[[NSDate alloc] init] timeIntervalSince1970];
    
    // 签名
    NSString* sign = [self getSign:aesjson :[NSString stringWithFormat:@"%ld",nowtime * 1000]];
    
    
    // 最后的参数
    NSDictionary* finalPar = @{@"access_key":accessKey,@"sign":sign,@"params":aesjson,@"timestamp":@(nowtime * 1000)};
    
    // 最后参数的二进制形式
    
    NSString* finalJson = [self convertToJsonData:finalPar];

    NSData *finalData = [finalJson dataUsingEncoding:NSUTF8StringEncoding];
    
     manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    manager.securityPolicy = [AFSecurityPolicy policyWithPinningMode:AFSSLPinningModeNone];
     manager.requestSerializer.timeoutInterval = 10;
     manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json",@"text/json", @"text/plain", @"text/html", nil];
    
    NSMutableURLRequest* request = [[AFJSONRequestSerializer serializer] requestWithMethod: @"POST" URLString:finalUrl parameters:nil error:nil];

    [request setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:finalData];
    [[manager dataTaskWithRequest:request uploadProgress:nil downloadProgress:nil completionHandler:^(NSURLResponse * _Nonnull response, id  _Nullable responseObject, NSError * _Nullable error) {
            if (responseObject) {
                NSData* responseData = responseObject;
                NSString* responseStr = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
                NSDictionary* dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
                NSString* aesStr = dict[@"data"];
                NSString* deaesStr = [aesStr aci_decryptWithAES];
                NSLog(@"%@",deaesStr);
            }else{
                NSLog(@"拉闸了");
            }
        }] resume];
}

- (NSString*)getSign:(NSString*)parStr :(NSString*)timeStr{
    NSData* pardata = [parStr dataUsingEncoding:NSUTF8StringEncoding];
    NSString* salt = [NSString stringWithFormat:@"%@%@",accessToken,timeStr];
    NSData* saltdata = [salt dataUsingEncoding:NSUTF8StringEncoding];
    
    NSData* sha256Data = [HmacSha256 sha256WithData:pardata key:saltdata];
    return  [sha256Data base64EncodedStringWithOptions:0];

}


- (NSString *)convertToJsonData:(NSDictionary *)dict

{
            NSError *parseError = nil;

            NSData *jsonData = [NSJSONSerialization dataWithJSONObject:dict options:NSJSONWritingPrettyPrinted error:&parseError];

    NSString* str = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
//    str = [str stringByReplacingOccurrencesOfString:@"\n" withString:@""];
//    str = [str stringByReplacingOccurrencesOfString:@" " withString:@""];
    return str;
    
}


@end
