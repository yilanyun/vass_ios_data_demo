//
//  YLHttpCenter.h
//  YLAPIDemo-OC
//
//  Created by Jabne on 2022/5/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YLHttpCenter : NSObject
+ (instancetype)shared;

- (void)requestUrlWithPath:(NSString *)path
parameters:(id)parameters
 success:(void (^)(id))success
 failure:(void (^)(NSError * error))failure;
@end

NS_ASSUME_NONNULL_END
