//
//  interfaceUrl.h
//  YLAPIDemo-OC
//
//  Created by Jabne on 2022/5/24.
//

#ifndef InterfaceUrl_h
#define InterfaceUrl_h


static NSString *const KLoginPath = @"/community/login";
static NSString *const kGetFeedPath = @"/video/feed";
static NSString *const kRelationPath = @"/video/relation";
static NSString *const kGetChannelPath = @"/video/channels";
static NSString *const kDetailPath = @"/video/getvideos";
static NSString *const KCPInfoPath = @"/video/cpinfo";
static NSString *const KCPVideosPath = @"/video/cpvideos";
static NSString *const kPlayPath = @"/vaas/video/play";

#endif /* InterfaceUrl_h */
