//
//  SceneDelegate.h
//  YLAPIDemo_OC
//
//  Created by Jabne on 2022/5/26.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

