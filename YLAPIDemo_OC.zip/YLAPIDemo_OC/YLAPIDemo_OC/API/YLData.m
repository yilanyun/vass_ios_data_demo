//
//  YLData.m
//  YLAPIDemo-OC
//
//  Created by Jabne on 2022/5/24.
//

#import "YLData.h"
#import "InterfaceUrl.h"
#import "YLHttpCenter.h"
@implementation YLData

+ (instancetype)shared{
    static YLData *s = nil ;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (s == nil) {
            s = [[YLData alloc]init];
        }
    });
  return s;

}

- (void)getFeedListWith:(int)videoType channelId:(int)channelId loadType:(int)loadType size:(int)size success:(void (^)(id _Nonnull))success failure:(void (^)(NSError * error))failure{
    
    NSDictionary* params = @{@"video_type":@(videoType),@"channel_id":@(channelId),@"load_type":@(loadType),@"size":@(size)};
    [[YLHttpCenter shared] requestUrlWithPath:kGetFeedPath parameters:params success:^(id obj) {
            
        } failure:^(NSError * _Nonnull error) {
            
        }];
}
- (void)getRelationListWithVideoId:(NSString *)videoId size:(int)size success:(void (^)(id _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure{
    NSDictionary* params = @{@"id" : videoId,@"size":@(size)};
    [[YLHttpCenter shared] requestUrlWithPath:kRelationPath parameters:params success:^(id obj) {
            
        } failure:^(NSError * error) {
            
        }];
}
- (void)getChannelsWithsuccess:(void (^)(id _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure{
    [[YLHttpCenter shared] requestUrlWithPath:kGetChannelPath parameters:@{} success:^(id obj) {
            
        } failure:^(NSError * error) {
            
        }];
}

- (void)getVideoDetailWithvideoIds:(NSString *)videoIds videoType:(int)videoType success:(void (^)(id _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure{
    NSDictionary* params = @{@"ids" : videoIds,@"video_type":@(videoType)};
    [[YLHttpCenter shared] requestUrlWithPath:kDetailPath parameters:params success:^(id _Nonnull) {
            
        } failure:^(NSError * _Nonnull error) {
            
        }];
}

- (void)getCpInfoWithcpId:(NSString *)cpId videoType:(int)videoType success:(void (^)(id _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure{
    NSDictionary* params = @{@"id" : cpId,@"video_type":@(videoType)};
    [[YLHttpCenter shared] requestUrlWithPath:KCPInfoPath parameters:params success:^(id obj) {
            
        } failure:^(NSError * error) {
            
        }];
}

- (void)getCpVideosWithvideoId:(NSString *)cpId videoType:(int)videoType page:(int)page size:(int)size success:(void (^)(id _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure{
    NSDictionary* params = @{@"id" : cpId,@"video_type":@(videoType),@"page":@(page),@"size":@(size)};
    [[YLHttpCenter shared] requestUrlWithPath:KCPVideosPath parameters:params success:^(id obj) {
            
        } failure:^(NSError * error) {
            
        }];
}

- (void)requestVideoInfoWithVideoId:(NSString *)videoId success:(void (^)(id _Nonnull))success failure:(void (^)(NSError * _Nonnull))failure{
    NSDictionary* params = @{@"id" : videoId};
    [[YLHttpCenter shared] requestUrlWithPath:kPlayPath parameters:params success:^(id obj) {
        
    } failure:^(NSError * error) {
        
    }];
}

@end
