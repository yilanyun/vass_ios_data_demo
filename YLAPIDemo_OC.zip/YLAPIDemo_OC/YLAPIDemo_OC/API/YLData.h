//
//  YLData.h
//  YLAPIDemo-OC
//
//  Created by Jabne on 2022/5/24.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface YLData : NSObject
+ (instancetype)shared;
/**
 频道信息流
 @param videoType : 视频类型，1-横屏，2-竖屏
 @param channelId : 频道ID
 @param loadType : 0-上拉，1-下拉，2-首次刷新
 @param size : 页大小，范围 1～8
 */
- (void)getFeedListWith:(int)videoType channelId:(int)channelId loadType:(int)loadType size:(int)size success:(void (^)(id))success failure:(void (^)(NSError * error))failure;


/**
 相关视频
 @param videoId : 视频id
 @param size : 页大小，范围 1～20
 */
- (void)getRelationListWithVideoId:(NSString*)videoId size:(int)size success:(void (^)(id))success failure:(void (^)(NSError * error))failure;

/**
 频道列表
 */
- (void)getChannelsWithsuccess:(void (^)(id))success failure:(void (^)(NSError * error))failure;

/**
 视频详情
 @param videoIds : 视频id用逗号隔开组成的字符串
 @param videoType : 视频类型，1-横屏，2-竖屏
 */
- (void)getVideoDetailWithvideoIds:(NSString*)videoIds videoType:(int)videoType success:(void (^)(id))success failure:(void (^)(NSError * error))failure;

/**
 获取作者信息
 @param cpId : 作者id
 @param videoType : 视频类型，1-横屏，2-竖屏
 */
- (void)getCpInfoWithcpId:(NSString*)cpId videoType:(int)videoType success:(void (^)(id))success failure:(void (^)(NSError * error))failure;

/**
 获取作者视频
 @param cpId : 视频id
 @param videoType : 视频类型，1-横屏，2-竖屏
 @param page : 第几页自己控制
 @param size : 每页的数量
 */
- (void)getCpVideosWithvideoId:(NSString*)cpId videoType:(int)videoType page:(int)page size:(int)size success:(void (^)(id))success failure:(void (^)(NSError * error))failure;

/**
 获取视频播放信息
 @param videoId : 视频id
 */
- (void)requestVideoInfoWithVideoId:(NSString*)videoId success:(void (^)(id))success failure:(void (^)(NSError * error))failure;
@end

NS_ASSUME_NONNULL_END
