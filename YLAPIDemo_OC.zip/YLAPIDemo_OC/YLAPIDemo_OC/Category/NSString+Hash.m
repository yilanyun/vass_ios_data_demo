//
//  NSString+Hash.m
//  YLAPIDemo-OC
//
//  Created by Jabne on 2022/5/23.
//

#import "NSString+Hash.h"
#import <CommonCrypto/CommonHMAC.h>
#import <GTMBase64/GTMBase64.h>

@implementation NSString (Hash)
- (NSString *)hmacSHA256StringWithKey:(NSString *)key
{
    NSData *keyData = [key dataUsingEncoding:NSUTF8StringEncoding];
//    NSData *messageData = [self dataUsingEncoding:NSUTF8StringEncoding];
//    NSMutableData *mutableData = [NSMutableData dataWithLength:CC_SHA256_DIGEST_LENGTH];
//    CCHmac(kCCHmacAlgSHA256, keyData.bytes, keyData.length, messageData.bytes, messageData.length, mutableData.mutableBytes);
//    return  [mutableData base64EncodedStringWithOptions:0];
    
    NSData *hashData = [self dataUsingEncoding:NSUTF8StringEncoding];
    
    unsigned char *digest;
    digest = malloc(CC_SHA256_DIGEST_LENGTH);
    //const char *cKey = [key cStringUsingEncoding:NSUTF8StringEncoding];
    CCHmac(kCCHmacAlgSHA256, [keyData bytes], [keyData length], [hashData bytes], [hashData length], digest);
//    NSData* endData = [[NSData alloc] initWithBytes:digest length:CC_SHA256_DIGEST_LENGTH];
    NSString *encode = [self stringFromBytes:digest length:CC_SHA256_DIGEST_LENGTH];
//    NSData* data = [encode dataUsingEncoding:NSUTF8StringEncoding];
//    NSString* str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
//    NSString* str = [endData base64EncodedStringWithOptions:0];
    free(digest);
    key = nil;
    return encode;
}


#pragma mark - Bytes转字符串
/**
 字符大小写可以通过修改“%02X”中的x修改,下面采用的是大写
 */
- (NSString *)stringFromBytes:(uint8_t *)bytes length:(int)length {
    NSMutableString *strM = [NSMutableString string];
    
    for (int i = 0; i < length; i++) {
        [strM appendFormat:@"%02X", bytes[i]];
    }
    
    return [strM copy];
}

@end
