//
//  JsonTool.swift
//  YLAPIDemo_OC
//
//  Created by Jabne on 2022/5/26.
//

import UIKit

@objc class JsonTool: NSObject {

    @objc class func dictToJson(dict:Dictionary<String, Any>)->String?{
        guard let data = try? JSONSerialization.data(withJSONObject: dict,
                                                     options:[] ) else {
            return nil
        }
        guard let str = String(data: data, encoding: .utf8) else {
            return nil
        }
return str
    }
}
