//
//  HmacSha256.swift
//  YLAPIDemo_OC
//
//  Created by Jabne on 2022/5/26.
//

import UIKit
import CommonCrypto
@objc class HmacSha256: NSObject {

    @objc class func sha256(data:Data,key:Data)->(Data){
        let count = data.count
        let digestLen = Int(CC_SHA256_DIGEST_LENGTH)

        return data.withUnsafeBytes { bytes -> Data in
            let result = UnsafeMutablePointer<UInt8>.allocate(capacity: digestLen)
            defer {
                result.deallocate()
            }
            key.withUnsafeBytes { body in
                CCHmac(CCHmacAlgorithm(kCCHmacAlgSHA256), body.baseAddress, key.count, bytes.baseAddress, count, result)
            }
            return Data(bytes: result, count: digestLen)
        }
    }
}
