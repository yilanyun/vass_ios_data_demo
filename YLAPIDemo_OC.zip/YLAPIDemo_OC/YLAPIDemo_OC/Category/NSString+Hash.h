//
//  NSString+Hash.h
//  YLAPIDemo-OC
//
//  Created by Jabne on 2022/5/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSString (Hash)
- (NSString *)hmacSHA256StringWithKey:(NSString *)key;
@end

NS_ASSUME_NONNULL_END
