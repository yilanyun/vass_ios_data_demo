//
//  YLHttpBaseModel.swift
//  YLVideo
//
//  Created by zhoubl on 2018/12/13.
//  Copyright © 2018 zhoubl. All rights reserved.
//

import UIKit

class YLHttpResult: NSObject, Decodable,Encodable
{
    // server响应相关
    var code: String?
    var msg: String?
    var data: String?
    var logid: String?
    var last_pg: String?
    var retcode: String?
    var retmsg: String?
    var log_id: String?

    var serverErrorCode: String? {
        if YLTools.isEmptyString(string: code) {
            return retcode
        }
        return code
    }
    var serverErrormsg: String? {
        if YLTools.isEmptyString(string: msg) {
            return retmsg
        }
        return msg
    }
    var logID: String? {
        if YLTools.isEmptyString(string: logid) {
            return log_id
        }
        return logid
    }
    
    // net响应相关
    var netErrorCode : Int?
    var netErrorMsg: String?
    
    var success : Bool {
        get {
            return netErrorCode == nil && serverErrorCode == "200"
        }
    }
    
    var errorCode: String {
        get {
            var code = ""
            if let netCode = netErrorCode {
                code = "\(netCode)"
            } else if let serverCode = serverErrorCode {
                code = serverCode
            }
            return code
        }
    }
    
    var errorMsg: String {
        get {
            var msg = ""
            if let netMsg = netErrorMsg {
                msg = netMsg
            } else if let serverMsg = serverErrormsg {
                msg = serverMsg
            }
            return msg
        }
    }
}

class YLDataModel<T: Decodable>: NSObject, Decodable
{
    var data: T?
}

extension Decodable
{
    static func deserialize(from json: String?) -> Self?
    {
        if let jsondata = json?.data(using: .utf8) {
            return try? JSONDecoder().decode(self, from: jsondata)
        }
        return nil
    }
}

extension Encodable
{
    func toJson() -> String?
    {
        if let data = try? JSONEncoder().encode(self) {
            var str = String(data: data, encoding: .utf8)
            str = str?.replacingOccurrences(of: "\"[", with: "[").replacingOccurrences(of: "]\"", with: "]").replacingOccurrences(of: "\\", with: "").replacingOccurrences(of: "\"{", with: "{").replacingOccurrences(of: "}\"", with: "}")
            return str
        }
        return ""
    }
}

extension KeyedDecodingContainer
{
    public func decodeIfPresent(_ type: String.Type, forKey key: K) throws -> String? {
        if let value = try? decode(type, forKey: key) {
            return value
        }
        if let value = try? decode(Int.self, forKey: key) {
            return String(value)
        }
        if let value = try? decode(Float.self, forKey: key) {
            return String(value)
        }
        return nil
    }
    
    public func decodeIfPresent(_ type: Int.Type, forKey key: K) throws -> Int? {
        if let value = try? decode(type, forKey: key) {
            return value
        }
        if let value = try? decode(String.self, forKey: key) {
            return Int(value)
        }
        return nil
    }
    
    public func decodeIfPresent(_ type: Float.Type, forKey key: K) throws -> Float? {
        if let value = try? decode(type, forKey: key) {
            return value
        }
        if let value = try? decode(String.self, forKey: key) {
            return Float(value)
        }
        return nil
    }
    
    public func decodeIfPresent(_ type: Bool.Type, forKey key: K) throws -> Bool? {
        if let value = try? decode(type, forKey: key) {
            return value
        }
        if let value = try? decode(String.self, forKey: key) {
            if let valueInt = Int(value) {
                return Bool(valueInt != 0)
            }
            return nil
        }
        if let value = try? decode(Int.self, forKey: key) {
            return Bool(value != 0)
        }
        return nil
    }
    
    public func decodeIfPresent(_ type: Double.Type, forKey key: K) throws -> Double? {
        if let value = try? decode(type, forKey: key) {
            return value
        }
        if let value = try? decode(String.self, forKey: key) {
            return Double(value)
        }
        return nil
    }
    
    public func decodeIfPresent<T>(_ type: T.Type, forKey key: K) throws -> T? where T : Decodable {
        return try? decode(type, forKey: key)
    }
}
