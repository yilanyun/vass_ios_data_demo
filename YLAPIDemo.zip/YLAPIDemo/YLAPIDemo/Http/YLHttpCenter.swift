//
//  YLHttpCenter.swift
//  YLHowTo
//
//  Created by yanpei on 2017/8/11.
//  Copyright © 2017年 yilan. All rights reserved.
//

import UIKit
import AdSupport
import UIKit
import Alamofire
let baseUrl = "https://api.yilanvaas.cn"
//let baseUrl = "http://testapi.yladm.com/mallen"
let playbaseUrl = "https://play.yilanvaas.cn"
let KLoginPath = "/community/login"
let kGetFeedPath = "/video/feed"
let kRelationPath = "/video/relation"
let kGetChannelPath = "/video/channels"
let kDetailPath = "/video/getvideos"
let KCPInfoPath = "/video/cpinfo"
let KCPVideosPath = "/video/cpvideos"
let kPlayPath = "/vaas/video/play"

class YLHttpCenter
{
    static let shared = YLHttpCenter()
    
    
    func requestUrl<T: Decodable>(_ path: String,
                                  host: String? = nil,
                                  method: HTTPMethod = .post,
                                  parameters : [String : Any] = [:],
                                  completionHandler: @escaping (YLHttpResult, T?) -> Void) -> Void
    {
        // 域名
        var hostUrl = baseUrl
        
        if path == kPlayPath {
            hostUrl = playbaseUrl
        }
        
        // 参数
        let timeStamp = NSDate().timeIntervalSince1970.intValue
        let bundleID = Bundle.main.object(forInfoDictionaryKey: "CFBundleIdentifier") as? String ?? ""
        // 公共参数
        var publicParams = ["platform" : 2, //1-Android，2-iOS，3-H5，4-小程序，5-web
                            "udid" : YLUUID.value.prefix(60),// udid
                            "pkg_name": bundleID
        ] as [String : Any]
        
        // 公共参数加传入的参数
        publicParams += parameters
        
        // 参数转json
        let paramsjson =  publicParams.toJsonString()!
        
        // json数据AES加密
        let aesStr = YLAES.Endcode_AES_ECB(strToEncode: paramsjson)
        
        // 签名
        let timeStr = String(format: "%ld", timeStamp * 1000)
        let sign = YLHttpCenter.getSign(paramsStr: aesStr, timeStr: timeStr)
        
        // 最后post的参数
        let wholeParams = ["access_key":accessKey,
                           "sign":sign,
                           "params":aesStr,
                           "timestamp":timeStamp * 1000
        ] as [String : Any]
        
        print(hostUrl + path,wholeParams.toJsonString()!)
        
        let jsonStr = wholeParams.toJsonString()!
        let jsonData = jsonStr.data(using: .utf8)
        var request = URLRequest(url: URL(string: hostUrl + path)!)
        request.httpMethod = method.rawValue
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = jsonData
        Alamofire.request(request).responseString { (response) in
            print(response.result.value as Any)
            let jsonstr = response.result.value
            let result:YLHttpResult = YLHttpResult.deserialize(from: jsonstr) ?? YLHttpResult()
            if let err = response.result.error {
                let nserr = err as NSError
                result.netErrorCode = nserr.code
                result.netErrorMsg = nserr.domain
            }
            let destr = YLAES.Decode_AES_ECB(strToDecode: result.data ?? "")
            result.data = destr
            let responseJson = result.toJson()
            let responseObject = T.deserialize(from: responseJson)
            completionHandler(result, responseObject)
        }
    }
    
    
    // 自有平台鉴权
    class func getSign(paramsStr: String, timeStr: String) -> String
    {
        let stringToSign = paramsStr
        let salt = accessToken + timeStr
        var sign = ""
        if let stringToSignData = stringToSign.data(using: .utf8) {
            let sha256Data = stringToSignData.digest(.sha256, key: salt)
            sign = sha256Data.base64EncodedString()
        }
        return sign
    }
}


func += <KeyType, ValueType> ( left: inout Dictionary<KeyType, ValueType>, right: Dictionary<KeyType, ValueType>?)
{
    guard let right = right else {
        return
    }
    for (k, v) in right
    {
        left.updateValue(v, forKey: k)
    }
}


extension Dictionary {
    
    func toJsonString() -> String? {
                guard let data = try? JSONSerialization.data(withJSONObject: self,
                                                             options:[] ) else {
                    return nil
                }
                guard let str = String(data: data, encoding: .utf8) else {
                    return nil
                }
        return str
    }
    
}
