//
//  YLNetworkManager.swift
//  YLDataSDK
//
//  Created by yanpei on 2019/1/14.
//  Copyright © 2019 yilan. All rights reserved.
//

import Foundation
import Alamofire

class YLNetworkManager
{
    enum Status
    {
        case unknown
        case notReachable
        case wwan
        case wifi
    }
    
    static let shared = YLNetworkManager()
    
    private(set) var status: Status = .unknown
    {
        willSet {
            lastStatus = status
        }
    }
    private(set) var lastStatus: Status = .unknown
    
    private var networkReachability = NetworkReachabilityManager.init()
    private var notiCenter = NotificationCenter.init()
    private var fakeTimer : Timer?
    
    init()
    {
        self.status = self.getStatusFrom(networkReachability!.networkReachabilityStatus)
        
        networkReachability!.listener = notifyListener
        networkReachability?.startListening()
    }
    
    func addStatusChangeObserver(_ observer: Any, selector aSelector: Selector)
    {
        notiCenter.addObserver(observer, selector: aSelector, name: NSNotification.Name("YLNetworkStatusChanged"), object: nil)
    }
    
    func removeStatusChangeObserver(_ observer: Any)
    {
        notiCenter.removeObserver(observer, name: NSNotification.Name("YLNetworkStatusChanged"), object: nil)
    }
    
    private func notifyListener(_ flags: NetworkReachabilityManager.NetworkReachabilityStatus)
    {
        //        YLTools.SDKDebugLog("nnn networkstauts \(flags)")
        
        if self.status != self.getStatusFrom(flags) {
            self.status = self.getStatusFrom(flags)
            notiCenter.post(name: NSNotification.Name("YLNetworkStatusChanged"), object: nil)
        }
    }
    
    private func getStatusFrom(_ flags: NetworkReachabilityManager.NetworkReachabilityStatus) -> Status
    {
        var status: Status
        switch flags
        {
        case .unknown:
            status = .unknown
        case .notReachable:
            status = .notReachable
        case .reachable(.wwan):
            status = .wwan
        case .reachable(.ethernetOrWiFi):
            status = .wifi
        }
        return status
    }
    
    func fakeStatus()
    {
        if #available(iOS 10.0, *) {
            
            fakeTimer = Timer.scheduledTimer(withTimeInterval: 10, repeats: true, block: { (timer) in
                if self.status == .wifi {
                    self.status = .wwan
                } else {
                    self.status = .wifi
                }
                self.notiCenter.post(name: NSNotification.Name("YLNetworkStatusChanged"), object: nil)
                //                YLTools.SDKDebugLog("\(self.status)")
            })
        } else {
            // Fallback on earlier versions
        }
    }
}
