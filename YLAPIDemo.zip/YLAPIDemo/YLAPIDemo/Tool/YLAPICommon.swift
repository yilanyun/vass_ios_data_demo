//
//  YLAPICommon.swift
//  YLAPIDemo
//
//  Created by Jabne on 2021/7/6.
//

import UIKit

let accessKey:String = "ylel2vek386q"
let accessToken:String = "talb5el4cbw3e8ad3jofbknkexi1z8r4"
