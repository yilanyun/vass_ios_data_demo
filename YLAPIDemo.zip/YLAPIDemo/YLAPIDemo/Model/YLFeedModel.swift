//
//  YLFeedModel.swift
//  YLVideo
//
//  Created by zhoubl on 2018/12/13.
//  Copyright © 2018 zhoubl. All rights reserved.
//

import UIKit

/// 视频信息
class YLFeedModel: NSObject, Decodable
{
    /// 视频ID
     var video_id: String?
    /// 标题
     var title: String?
    /// 封面
     var cover: String?
    /// 分类
     var category: String?
    /// 标签
     var tags: String?
    /// h5url
     var h5_url: String?
    /// pcurl
     var pc_url: String?
    /// 分享地址
     var share_url: String?
    /// 发布时间
     var publish_time: String?
    /// 播放时长
     var duration: String?
    /// 作者信息
    var author: YLProviderModel?
    /// 视频内容宽
     var video_w: String?
    /// 视频内容高
     var video_h: String?
    /// 视频大小
     var file_size: String?
    /// 播放数
     var play_num: String?
    /// 点赞数
     var like_num: String?
    
}




