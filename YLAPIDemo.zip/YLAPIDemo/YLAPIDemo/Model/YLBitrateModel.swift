//
//  YLBitrateModel.swift
//  YLAPIDemo
//
//  Created by Jabne on 2021/7/12.
//

import Foundation

class YLBitrateModel : NSObject, Decodable
{
    var code: String?
    var name: String?  // 码率的名字: "标清", "高清"...
    var uri: String?
    var size: String?
}
