//
//  YLReport.swift
//  YLDataSDK
//
//  Created by yanpei on 2019/1/14.
//  Copyright © 2019 yilan. All rights reserved.
//

import Foundation
/// 上报
 class YLReport: NSObject
{
    /// 单例
     static var shared = YLReport()
    private var videoShowedID = [String]()
   
    /**
     视频展现上报
     @param videoInfo : 视频id
     @param pos : 视频在信息流或者相关页出现的位置，从1开始计算
     @param referpage 展现来源，channel_xxx-feed页，vplaypage-相关页
     对referpage说明
     频道页：channel_xxx，其中xxx为频道id
     相关页：vplaypage
     */
    
    func videoShow(videoId: String, pos: Int,referpage:String)
    {
//        if !YLTools.isEmptyString(string: videoId) {
//            if videoShowedID.contains(videoId) {
//                return
//            }
//            videoShowedID.append(videoId)
//        }
        let parameters = ["videoid" : videoId,
                          "pos": "\(pos)",
                          "referpage": referpage]
        YLReportCenter.shared.send(path: "videoshow", parameters: parameters)
    }
    
    
    /// 视频播放
    @objc func videoPlay(videoId: String, repeat: Bool = false,referpage:String)
    {
        if `repeat` {
            
        } else {
            
            YLReportCenter.resetTaskID(with: videoId)
        }
        let params = ["videoid" : videoId,
                      "taskid" : YLReportCenter.taskID(from: videoId),
                      "referpage": referpage]
        YLReportCenter.shared.send(path: "videoplay", parameters: params)
    }
    
    

    

    
    
}

