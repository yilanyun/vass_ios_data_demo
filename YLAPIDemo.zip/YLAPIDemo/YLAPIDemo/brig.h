//
//  brig.h
//  YLAPIDemo
//
//  Created by Jabne on 2021/7/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface brig : NSObject

@end

NS_ASSUME_NONNULL_END
