//
//  YLAPIHomeTableViewController.swift
//  YLAPIDemo
//
//  Created by Jabne on 2021/7/9.
//

import UIKit

class YLAPIHomeTableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            // feed:获取信息流
            YLData.shared.getFeedList(videoType: 1 , channelId: 1291, loadType: .first, size: 8) { (result, list) in
                print(list as Any)
            }
            
            break
        case 1:
            // relation:获取相关视频
            YLData.shared.getRelationList(videoId: "vM4P2Rv2xVMY", size: "8") { (reslut, list) in
                print(list as Any)
            }
            break
        case 2:
            // channels:获取频道
            YLData.shared.getChannels { (result, list) in
                print(list as Any)
            }
            break
        case 3:
            // getvideos:获取视频们的详情们
            // 视频详情是传多个视频id逗号隔开，数组形式返回多个视频详情
            YLData.shared.getVideoDetail(videoIds: "vM4P2Rv2xVMY", videoType: 1) { (reslut, detaiList) in
                print(detaiList as Any)
            }
            break
        case 4:
            // cpinfo:获取视频的作者
            YLData.shared.getCpInfo(cpId: "qJy8nVw1ojRY", videoType: 1) { (reslut, model) in
                print(model as Any)
            }
            break
        case 5:
            // cpvideos:获取作者视频列表
            YLData.shared.getCpVideos(videoId: "qJy8nVw1ojRY", videoType: 1, page: 1, size: 20) { (result, list) in
                print(list as Any)
            }
            break
        case 6:
            // play:获取视频播放url
            YLData.shared.requestVideoInfo(mediaID: "vM4P2Rv2xVMY") { (result, videomodel) in
                print(videomodel?.first?.uri as Any)
            }
            break
        case 7:
            // 视频展现上报
            YLReport.shared.videoShow(videoId: "vM4P2Rv2xVMY", pos: 1, referpage: "vplaypage")
            break
        case 8:
            // 视频播放上报
            YLReport.shared.videoPlay(videoId: "vM4P2Rv2xVMY", repeat: false, referpage: "vplaypage")
            break
        default:
            
            break
        }
    }
}
